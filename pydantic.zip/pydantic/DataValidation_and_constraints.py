from pydantic import BaseModel , Field
from typing import Optional , Annotated

class Student(BaseModel):
    name : str

    # if we want to add more restriction or validation
    # which kind of data should be entered and assumed 
    # correct we can also do that
    # Asssum you university only take student age between 18 to 24
    # more than that is invalid

    # You can use "Field" this used to these same kind of 
    # validations it works for both int and str datatypes

    age : int = Field(gt=17,lt=25) 
    # gt greater than 17 , le less than 25
    # ge greater than equal to
    # lt less than equal to

    weight : Optional[int] = Field(default=None,gt=0)
    # cant be negative
    # default=None means its optional
    # Some fact about pydantic if you given data in string
    # and the data inside string is actaully int then it also accept
    # that string and convert it into string
    # same goes for Float

    # 🌟 This is knows as typeCohersion if i am not wrong

    # But it is suggested dont do those shit sometime it can cause problem
    # if you are not sure about it

    # 🌟 IF YOU WANT TO MAKE SURE THE DATA NEVER PASSED AS STRING THEN SET
    # field( strict = True)


    gender : Optional[str] = Field(max_length=1)
    # max string len can only be one


    # If you want to add metaData then you use Annotated.
    # Annoted is a part of Typing Module and you can also use
    # Field with it 

    # Annotated( dataType , Field(constraints , title , description , example ) , )
    address : Annotated[
        str,
        Field(
            default=None,
            max_length=200,
            title="Enter Address",
            description="Address Field is optional , MaxLenght = 200 , DataType String"
        ),
    ]


def insert_into_db(s : Student):
    print(f"{s.name} {type(s.name)}")
    print(f"{s.age} {type(s.age)}")
    print(f"{s.gender} {type(s.gender)}")
    print(s.address)

stu1  = Student(
    name="sinchan", 
    age="24", # this will still work 
    gender="M",
    address="Some Steet No.700 , somewhere in delhi , Somewhere in India PINCODE"
)

insert_into_db(stu1)
