from pydantic import BaseModel , Field , field_validator , EmailStr
from typing import Optional , Annotated , Dict

# why do we use field validators
# Field() used for simple constrainst and validations
#
# we use Field_validator for more complex validations or constraints
# like is your email address contain any specific bank domain
# like is you name contain numbers something like that
#
# 

class Pateint(BaseModel):
    name : str
    email : EmailStr
    age : int | None = None
    contact_deatils : Dict[str,str] | None = None   

    # Now i need to validatae that email domain should
    # be from [ hdfc.com , sbi.com , axis.com ]
    # we cant do this kind of validation from Field
    # we need to use field_validator

    # field valiator use some kind of decorator
    # and need to create a custom method in class


    # @field_validator("on which field , enter name of it here ")

    @field_validator("email")
    @classmethod # ea method jo aap bana rahya hoo vo eak class method hai
    def emailValidator(cls , value:str):
        # it takes two paramets 1st class , 2nd value on which we
        # going to work

        validDomains = ["hdfc.com","sbi.com","axis.com"]

        # split the string in two part before and after '@'
        domain_name = value.split('@')[-1] 
        # this will return a list and we fetch the last par which we want

        if domain_name not in validDomains :
            raise ValueError("Not a valid Domain")

        # else
        return value



    # you can also permform transformation on data
    # like if you want to name should be UPPERCASE
    @field_validator('name')
    @classmethod
    def transform_name_to_upperCase(cls,value):
        return value.upper()




    # 🌟 field_validator works in two modes : before and after
    #
    # after  = this is deafult , 1st type cohersion happen then value get
    #          passed into validators
    # before = 1st value is passed to field_validator then type cohersion 
    #          happen
    #
    # field_validator(mode="after") which is default in my opinion after is
    # better



    # ====================================================================
    # 🌟
    # data validation when more than one field is require for validataion
    # if age < 60 then contact details should have a Emergency Phone Number
    # if Emergency number not available we will not create patient
    # if its available we will create patient

    # We cant use field validator here because field validator is for
    # single field for this we use Model Validator
    # => we will see that in next file

    # Video time stamps : 1:02:55



    


# this will throw error sice domain is not in valid domain

# p1 = Pateint(
#     name = "Brock",
#     email = "thisIsNotA_valid@gmail.com"
# ) # since it contain gmail

p2 = Pateint(
    name = "shinchan",
    email = "Valid_@sbi.com"
)

def printPatintData(p : Pateint):
    print(p.name)
    print(p.email)


printPatintData(p2)
