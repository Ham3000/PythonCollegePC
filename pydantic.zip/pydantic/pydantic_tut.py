from pydantic import BaseModel , EmailStr , AnyUrl
from typing import List , Optional

class Student(BaseModel):
    name : str 
    age : int
    gender : str
    weight : int | None = None

    # another way to describe optional
    subject : Optional[List[str]] = None # default value is None

    married : bool = False

    # Pydantic also gives you custom dataTypes
    # like you know email follow a specific pattern
    # yourName@something.com

    # if you do it manually validate it manually , what the user type is an email or not
    # it will be very pain in ass process. i am not saying you cant do that manually.
    # but to validate the entered string follows a email structure is time consuming
    # Pydantic provide us a DataType for that and it handle vallidation internally

    email : EmailStr | None = None

    # another CustomDataType AnyUrl which validate User given URL 
    # follow the correct URL or any URL format, if not will throw error

    portfolioLink : AnyUrl | None = None 
    # 

def insert_into_db(s : Student):
    print(f"{s.name} {type(s.name)}")
    print(f"{s.age} {type(s.age)}")
    print(f"{s.gender} {type(s.gender)}")
    print(f"{s.married} {type(s.married)}")
    print(f"{s.email} {type(s.email)}")


stu1  = Student(
    name="sinchan", 
    age=18, 
    gender="M",

    # bad email
    #email="thisfORGET.com" # this will fucking throw the error

    email = "whotheFuckKnows@somthing.com" # this will not
)
insert_into_db(stu1)