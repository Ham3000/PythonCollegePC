import 'dart:io';

import 'package:flutter/material.dart';
import 'package:youtube_explode_dart/youtube_explode_dart.dart';

void main() {
  runApp(const YouTubeDownloaderApp());
}

class YouTubeDownloaderApp extends StatelessWidget {
  const YouTubeDownloaderApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'YouTube Downloader',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.red,
        ),
        useMaterial3: true,
      ),
      home: const DownloaderPage(),
    );
  }
}

class DownloaderPage extends StatefulWidget {
  const DownloaderPage({super.key});

  @override
  State<DownloaderPage> createState() => _DownloaderPageState();
}

class _DownloaderPageState extends State<DownloaderPage> {
  final TextEditingController _urlController =
      TextEditingController();

  final YoutubeExplode _youtube = YoutubeExplode();

  Video? _video;
  List<MuxedStreamInfo> _streams = [];

  MuxedStreamInfo? _selectedStream;

  bool _fetching = false;
  bool _downloading = false;

  double _progress = 0;

  String? _error;
  String? _downloadedPath;

  Future<void> _fetchVideo() async {
    final url = _urlController.text.trim();

    if (url.isEmpty) {
      _showMessage('Please enter a YouTube URL.');
      return;
    }

    setState(() {
      _fetching = true;
      _error = null;
      _video = null;
      _streams = [];
      _selectedStream = null;
      _downloadedPath = null;
    });

    try {
      final video = await _youtube.videos.get(url);

      final manifest = await _youtube.videos.streams.getManifest(
        video.id.value,
      );

      final muxedStreams = manifest.muxed.toList();

      // Sort from highest quality to lowest quality.
      muxedStreams.sort(
        (a, b) => b.videoQuality.index.compareTo(
          a.videoQuality.index,
        ),
      );

      if (!mounted) return;

      setState(() {
        _video = video;
        _streams = muxedStreams;

        if (muxedStreams.isNotEmpty) {
          _selectedStream = muxedStreams.first;
        }
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _error = 'Failed to fetch video:\n$e';
      });
    } finally {
      if (mounted) {
        setState(() {
          _fetching = false;
        });
      }
    }
  }

  Future<void> _download() async {
    final video = _video;
    final streamInfo = _selectedStream;

    if (video == null || streamInfo == null) {
      _showMessage('Please fetch a video first.');
      return;
    }

    setState(() {
      _downloading = true;
      _progress = 0;
      _downloadedPath = null;
      _error = null;
    });

    IOSink? sink;

    try {
      final userProfile = Platform.environment['USERPROFILE'];

      if (userProfile == null) {
        throw Exception(
          'Could not find Windows user directory.',
        );
      }

      final downloadsDirectory = Directory(
        '$userProfile\\Downloads',
      );

      if (!await downloadsDirectory.exists()) {
        await downloadsDirectory.create(
          recursive: true,
        );
      }

      final safeTitle = _sanitizeFileName(video.title);

      final extension = streamInfo.container.name;

      final file = File(
        '${downloadsDirectory.path}\\$safeTitle.$extension',
      );

      final stream = _youtube.videos.streams.get(streamInfo);

      sink = file.openWrite();

      var downloadedBytes = 0;

      await for (final chunk in stream) {
        sink.add(chunk);

        downloadedBytes += chunk.length;

        final totalBytes = streamInfo.size.totalBytes;

        if (totalBytes > 0 && mounted) {
          setState(() {
            _progress =
                downloadedBytes / totalBytes;
          });
        }
      }

      await sink.flush();
      await sink.close();
      sink = null;

      if (!mounted) return;

      setState(() {
        _progress = 1;
        _downloadedPath = file.path;
        _downloading = false;
      });

      _showMessage(
        'Download completed successfully.',
      );
    } catch (e) {
      await sink?.close();

      if (!mounted) return;

      setState(() {
        _downloading = false;
        _error = 'Download failed:\n$e';
      });
    }
  }

  String _sanitizeFileName(String name) {
    var result = name.replaceAll(
      RegExp(r'[<>:"/\\|?*]'),
      '_',
    );

    result = result.replaceAll(
      RegExp(r'\s+'),
      ' ',
    );

    result = result.trim();

    // Windows doesn't like a filename ending with
    // a period or space.
    result = result.replaceAll(
      RegExp(r'[ .]+$'),
      '',
    );

    if (result.isEmpty) {
      result = 'youtube_video';
    }

    // Keep the path reasonably short.
    if (result.length > 150) {
      result = result.substring(0, 150);
    }

    return result;
  }

  String _formatDuration(Duration? duration) {
    if (duration == null) {
      return 'Unknown';
    }

    final hours = duration.inHours;
    final minutes =
        duration.inMinutes.remainder(60);
    final seconds =
        duration.inSeconds.remainder(60);

    if (hours > 0) {
      return '$hours:'
          '${minutes.toString().padLeft(2, '0')}:'
          '${seconds.toString().padLeft(2, '0')}';
    }

    return '$minutes:'
        '${seconds.toString().padLeft(2, '0')}';
  }

  String _formatBytes(int bytes) {
    if (bytes < 1024) {
      return '$bytes B';
    }

    if (bytes < 1024 * 1024) {
      return '${(bytes / 1024).toStringAsFixed(1)} KB';
    }

    if (bytes < 1024 * 1024 * 1024) {
      return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    }

    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
  }

  void _showMessage(String message) {
    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
      ),
    );
  }

  @override
  void dispose() {
    _urlController.dispose();
    _youtube.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final video = _video;

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'YouTube Downloader',
        ),
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(
            maxWidth: 800,
          ),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(32),
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.stretch,
              children: [
                const Icon(
                  Icons.download_for_offline,
                  size: 70,
                  color: Colors.red,
                ),

                const SizedBox(height: 15),

                Text(
                  'YouTube Downloader',
                  textAlign: TextAlign.center,
                  style: Theme.of(context)
                      .textTheme
                      .headlineMedium,
                ),

                const SizedBox(height: 8),

                Text(
                  'Paste a YouTube URL and download the video.',
                  textAlign: TextAlign.center,
                  style: Theme.of(context)
                      .textTheme
                      .bodyMedium,
                ),

                const SizedBox(height: 30),

                TextField(
                  controller: _urlController,
                  enabled: !_downloading,
                  decoration: InputDecoration(
                    hintText:
                        'https://www.youtube.com/watch?v=...',
                    prefixIcon:
                        const Icon(Icons.link),
                    suffixIcon: IconButton(
                      icon: const Icon(Icons.clear),
                      onPressed: () {
                        _urlController.clear();
                      },
                    ),
                    border: OutlineInputBorder(
                      borderRadius:
                          BorderRadius.circular(12),
                    ),
                  ),
                  onSubmitted: (_) {
                    _fetchVideo();
                  },
                ),

                const SizedBox(height: 12),

                SizedBox(
                  height: 50,
                  child: FilledButton.icon(
                    onPressed:
                        _fetching || _downloading
                            ? null
                            : _fetchVideo,
                    icon: _fetching
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child:
                                CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          )
                        : const Icon(Icons.search),
                    label: Text(
                      _fetching
                          ? 'Fetching...'
                          : 'Fetch Details',
                    ),
                  ),
                ),

                if (_error != null) ...[
                  const SizedBox(height: 20),
                  _ErrorCard(message: _error!),
                ],

                if (video != null) ...[
                  const SizedBox(height: 25),
                  _VideoCard(
                    video: video,
                    duration:
                        _formatDuration(
                      video.duration,
                    ),
                  ),

                  const SizedBox(height: 20),

                  if (_streams.isEmpty)
                    const Card(
                      child: Padding(
                        padding: EdgeInsets.all(20),
                        child: Text(
                          'No combined video/audio '
                          'streams are available for '
                          'this video.',
                        ),
                      ),
                    )
                  else ...[
                    Text(
                      'Download quality',
                      style: Theme.of(context)
                          .textTheme
                          .titleMedium,
                    ),

                    const SizedBox(height: 8),

                    DropdownButtonFormField<
                        MuxedStreamInfo>(
                      value: _selectedStream,
                      decoration:
                          const InputDecoration(
                        border: OutlineInputBorder(),
                      ),
                      items: _streams.map((stream) {
                        return DropdownMenuItem<
                            MuxedStreamInfo>(
                          value: stream,
                          child: Text(
                            '${stream.videoQuality.name} '
                            '• ${_formatBytes(
                              stream.size.totalBytes,
                            )}',
                          ),
                        );
                      }).toList(),
                      onChanged: _downloading
                          ? null
                          : (value) {
                              setState(() {
                                _selectedStream =
                                    value;
                              });
                            },
                    ),

                    const SizedBox(height: 15),

                    if (_downloading) ...[
                      LinearProgressIndicator(
                        value: _progress,
                      ),

                      const SizedBox(height: 8),

                      Text(
                        '${(_progress * 100).toStringAsFixed(0)}%',
                        textAlign: TextAlign.center,
                      ),

                      const SizedBox(height: 15),
                    ],

                    SizedBox(
                      height: 52,
                      child: FilledButton.icon(
                        onPressed:
                            _downloading
                                ? null
                                : _download,
                        icon: const Icon(
                          Icons.download,
                        ),
                        label: Text(
                          _downloading
                              ? 'Downloading...'
                              : 'Download',
                        ),
                      ),
                    ),
                  ],
                ],

                if (_downloadedPath != null) ...[
                  const SizedBox(height: 20),

                  Card(
                    color: Colors.green.shade50,
                    child: Padding(
                      padding:
                          const EdgeInsets.all(16),
                      child: Row(
                        children: [
                          const Icon(
                            Icons.check_circle,
                            color: Colors.green,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              'Saved to:\n'
                              '$_downloadedPath',
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],

                const SizedBox(height: 30),

                Text(
                  'Files are saved to your Windows Downloads folder.',
                  textAlign: TextAlign.center,
                  style: Theme.of(context)
                      .textTheme
                      .bodySmall,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _VideoCard extends StatelessWidget {
  final Video video;
  final String duration;

  const _VideoCard({
    required this.video,
    required this.duration,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Image.network(
            video.thumbnails.highResUrl,
            width: double.infinity,
            height: 300,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) {
              return Container(
                height: 300,
                color: Colors.grey.shade200,
                child: const Center(
                  child: Icon(
                    Icons.video_library,
                    size: 70,
                  ),
                ),
              );
            },
          ),

          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  video.title,
                  style: Theme.of(context)
                      .textTheme
                      .titleLarge,
                ),

                const SizedBox(height: 10),

                Text(
                  video.author,
                  style: Theme.of(context)
                      .textTheme
                      .bodyLarge,
                ),

                const SizedBox(height: 6),

                Row(
                  children: [
                    const Icon(
                      Icons.timer_outlined,
                      size: 18,
                    ),
                    const SizedBox(width: 5),
                    Text(duration),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ErrorCard extends StatelessWidget {
  final String message;

  const _ErrorCard({
    required this.message,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.red.shade50,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Text(
          message,
          style: TextStyle(
            color: Colors.red.shade900,
          ),
        ),
      ),
    );
  }
}
